# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Tic-Tac-Toe (Jogo da Velha) game with AI using the Minimax algorithm. Built for a university AI class to demonstrate game theory and adversarial search.

## Running the Application

```bash
python main.py
```

## Architecture

### Module Structure

- **game/**: Core game logic
  - `board.py`: Board state with 9-cell array, move/undo operations
  - `game_logic.py`: Win detection, terminal state check, scoring evaluation

- **ai/**: AI player implementations
  - `base_player.py`: Abstract base class requiring `get_move(board) -> (move, stats)`
  - `minimax_player.py`: Minimax algorithm with depth-aware scoring
  - `random_player.py`: Random move selection (for comparison)

- **gui/**: Tkinter interface
  - `game_gui.py`: Main GUI with three modes (PvP, PvE, EvE)

- **visualization/**: Post-game analysis
  - `game_history.py`: Collects move data during AI play
  - `game_visualizer.py`: Generates HTML visualization opened in browser

- **utils/**: Constants (PLAYER_X, PLAYER_O, scores)

### Key Patterns

**Minimax Flow**: `MinimaxPlayer.get_move()` → recursive `_minimax()` → `GameLogic.evaluate()` returns score adjusted by depth (faster wins score higher).

**Visualization**: Only collects data for AI moves. `GameHistoryCollector` records each move's alternatives and scores. At game end, `GameVisualizer.show()` generates HTML and opens browser.

**Board indexing**: 0-8 linear array representing 3x3 grid (0-2 top row, 3-5 middle, 6-8 bottom).

## Code Conventions

- Method names and docstrings in English
- GUI labels in Portuguese (Brazilian)
- All AI players must return `Tuple[int, Dict]` with move index and stats dict containing `nodes_evaluated` and `time_ms`

## Adding New AI Algorithms (e.g., Alpha-Beta, Negamax)

When implementing a new AI algorithm, follow these steps to maintain visualization compatibility:

### 1. Create the Player Class

Create `ai/new_algorithm_player.py` extending `BasePlayer`:

```python
from ai.base_player import BasePlayer
from game.board import Board
from game.game_logic import GameLogic

class NewAlgorithmPlayer(BasePlayer):
    def __init__(self, symbol: str):
        super().__init__(symbol)
        self.nodes_evaluated = 0
        self.opponent = PLAYER_O if symbol == PLAYER_X else PLAYER_X

    def get_move(self, board: Board) -> Tuple[int, Dict]:
        start_time = time.perf_counter()
        self.nodes_evaluated = 0
        move_scores = []  # REQUIRED: collect alternatives

        # Your algorithm logic here...
        # For each possible move, append to move_scores:
        # move_scores.append({'position': move, 'score': score})

        elapsed_ms = (time.perf_counter() - start_time) * 1000

        # REQUIRED stats structure for visualization:
        stats = {
            'nodes_evaluated': self.nodes_evaluated,
            'time_ms': round(elapsed_ms, 3),
            'alternatives': move_scores,      # List[Dict] with 'position' and 'score'
            'chosen_score': best_score        # Score of chosen move
        }
        return best_move, stats
```

### 2. Required Stats Structure

The `stats` dict returned by `get_move()` MUST contain:

| Key | Type | Description |
|-----|------|-------------|
| `nodes_evaluated` | `int` | Number of board states analyzed |
| `time_ms` | `float` | Computation time in milliseconds |
| `alternatives` | `List[Dict]` | All evaluated moves with scores |
| `chosen_score` | `int` | Score of the selected move |

Each item in `alternatives` must be: `{'position': int, 'score': int}`

### 3. Register in GUI

Edit `gui/game_gui.py`:

```python
# Add import at top
from ai.new_algorithm_player import NewAlgorithmPlayer

# Add to PLAYER_TYPES dict (line ~18)
PLAYER_TYPES = {
    'Minimax': MinimaxPlayer,
    'Random': RandomPlayer,
    'NewAlgorithm': NewAlgorithmPlayer,  # Add here
}
```

### 4. Enable Visualization Recording

Edit `gui/game_gui.py` in the `_ai_turn()` method (~line 332):

```python
# Change this check to include new algorithm:
if isinstance(player, (MinimaxPlayer, NewAlgorithmPlayer)):
    self.history.record_move(...)
```

### 5. Increment nodes_evaluated

Inside your recursive algorithm, increment counter for each state visited:

```python
def _your_algorithm(self, board, ...):
    self.nodes_evaluated += 1  # Count this node
    # ... rest of algorithm
```

### Visualization Output

The visualization will automatically show for your new algorithm:
- Timeline with each move's before/after board states
- 5-step decision process explanation (in Portuguese)
- All alternatives ranked with MELHOR/PIOR badges
- Score meanings: +10 (vitória), -10 (derrota), 0 (empate)
- Performance metrics (nodes evaluated, time)

### Example: Alpha-Beta Pruning

For Alpha-Beta, you might add extra stats:

```python
stats = {
    'nodes_evaluated': self.nodes_evaluated,
    'time_ms': round(elapsed_ms, 3),
    'alternatives': move_scores,
    'chosen_score': best_score,
    'pruned_branches': self.pruned_count  # Optional extra stat
}
```

The visualization will still work; extra fields are ignored but available for future enhancements.
